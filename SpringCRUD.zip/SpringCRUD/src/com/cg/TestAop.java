package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAop {

	public static void main(String[] args) {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
	Calculator c=(Calculator)ctx.getBean("calculator");
	System.out.println("sum(2,3) is ==>"+c.add(2, 3));
	System.out.println("sub(2,3) is ==>"+c.sub(2, 3));
	System.out.println("mul(2,3) is ==>"+c.mul(2, 3));
	System.out.println("div(20,3) is ==>"+c.div(20, 3));
	try {
	c.div(2, 0);
	}catch(Exception e) {
		System.out.println(e);
	}

	}

}
