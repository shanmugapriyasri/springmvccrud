package com.cg;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


public class MyXmlAspect {

	Log log=LogFactory.getLog(getClass());
	public MyXmlAspect() {
		System.out.println("Constructor");
	}
	//@Before("execution(* com.*.*(..))")
	public void beforem() {
		log.info("Log registered\n");
		log.info("Before is started\n");
		}
	//@AfterReturning(value="execution(* com.*.*(..))",returning="rtval")
	public void afterr() {
		log.info("After Return ");
		}
	//@After("execution(* com.*.*(..))")
	public void afterm() {
		log.info(" After method -Ended\n");
		}
	//@AfterThrowing(value="execution(* com.*.*(..))",throwing="ex")
	public void aftert() {
		log.info("Exception is occured");
		}
	
//	@Around(value="execution(* com.*.*(..))")
	public void aroundm() {
		log.info("=================== Around started ===============\n");
	//	log.info(jp.getSignature().getName());
		//log.info("Arguments are :"+Arrays.toString(jp.getArgs()));
		log.info("******************* around working ***********");
		log.info("=============== Around Ended======================");
		}
}
