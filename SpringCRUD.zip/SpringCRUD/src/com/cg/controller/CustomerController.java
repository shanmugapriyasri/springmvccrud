package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Customer;
import com.cg.beans.Gender;
import com.cg.dao.CustomerRepository;

@Controller
public class CustomerController {
	@Autowired
	Customer customer;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@RequestMapping("/")
	public ModelAndView first() {
		ModelAndView modelView=new ModelAndView();
		modelView.setViewName("Login");
		return modelView;
	}
	
	@RequestMapping("/registerlink")
	public String registerlink(ModelMap map) {
		map.addAttribute(customer);
		return "register";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(@Valid Customer customer,
			BindingResult errors) {
		ModelAndView modelView=new ModelAndView();
		if(errors.hasErrors()) {
			modelView.setViewName("register");
			modelView.addObject("status", "Not Registered try again");
		}else {
			customerRepository.save(customer);
		modelView.setViewName("Login");
		modelView.addObject("status", "Registed successfully");
		}
		return modelView;
	}
	
	@ModelAttribute("genderList")
	public List<Gender> populate(){
		ArrayList<Gender> list=new ArrayList<>();
		Gender g1=new Gender();
		g1.setType("Male");
		Gender g2=new Gender();
		g2.setType("Female");
		list.add(g1);
		list.add(g2);
		return list;
	}

	@RequestMapping(value="/loginvalidation",method=RequestMethod.POST)
	public ModelAndView validate(@RequestParam String username,
			@RequestParam String password,HttpServletRequest request) {
		ModelAndView modelView=new ModelAndView();
		HttpSession session=request.getSession();
		customer=customerRepository.validate(username, password);
		if(customer!=null) {
			if(customer.getRole().equals("customer")) {
			session.setAttribute("customer", customer);
			modelView.setViewName("customerhome");
			}
			else {
				session.setAttribute("customer", customer);
				modelView.setViewName("adminhome");
			}
		}else {
			modelView.addObject("status","Invalid username/password");
			modelView.setViewName("Login");
		}
		return modelView;
	}
	
	@RequestMapping("/viewprofile")
	public String viewProfile() {
		return "customerhome";
	}
	@RequestMapping("/viewbyId")
	public String viewbyId() {
		return "viewbyid";
	}
		
		@RequestMapping("/updateprofile")
public String updateprofile(ModelMap map,HttpServletRequest request) {
customer=(Customer) request.getSession().getAttribute("customer");
			map.addAttribute(customer);
		return "update";
		}
		
		
		@RequestMapping("/updatedata")
		public ModelAndView updatedata(@Valid Customer customer,
				BindingResult errors) {
			ModelAndView modelView=new ModelAndView();
			if(errors.hasErrors()) {
				modelView.setViewName("update");
				modelView.addObject("status", "Not updated try again");
			}else {
				customerRepository.update(customer);
			modelView.setViewName("Login");
			modelView.addObject("status", "updated successfully");
			}
			return modelView;
		}
		
		@RequestMapping("/viewall")
		public ModelAndView viewall() {
			ModelAndView modelView=new ModelAndView();
	List<Customer> customerList=customerRepository.getCustomers();
	modelView.addObject("customerList", customerList);
	modelView.setViewName("adminhome");
			return modelView;
			
		}
		
		@RequestMapping("/delete")
		public ModelAndView delete(@RequestParam Integer custId) {
			ModelAndView modelView=new ModelAndView();
	boolean status=customerRepository.delete(custId);
	if(status)
	modelView.addObject("status", "deleted  successfully");
	else
		modelView.addObject("status", "not deleted");
	modelView.setViewName("adminhome");
			return modelView;
			
		}
		@RequestMapping("/viewById")
		public String viewById() {
			return "viewbyid";
		}
		
		@RequestMapping("/viewdata")
		public ModelAndView viewdata(@RequestParam Integer custId) {
			ModelAndView modelView=new ModelAndView();
	Customer customer=customerRepository.getById(custId);
	modelView.addObject("customer", customer);
	modelView.setViewName("viewbyid");
			return modelView;
			
		}
		
		
	}
