package com.cg.dao;

import java.util.List;

import com.cg.beans.Customer;

public interface CustomerRepository {

	public void save(Customer customer);
	public void update(Customer customer);
	public boolean delete(int custId);
	public Customer getById(int custId);
	List<Customer> getCustomers();
	Customer validate(String username,String password);
	
}
