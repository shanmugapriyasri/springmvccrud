package com.ibm.rs;

import java.util.HashMap;



public class CustomerDao {
static HashMap<Integer, Customer> map=	new HashMap<Integer, Customer>();
	static {
		init();
	}
public static void init() {
		Customer e1=new Customer(1,"priya",21);
		Customer e2=new Customer(2,"riya",32);
		Customer e3=new Customer(3,"diya",22);
		map.put(e1.getId(),e1);
		map.put(e2.getId(),e2);
		map.put(e3.getId(),e3);
		}

	public Customer getCustomer(Integer id) {
		Customer e=map.get(id);
		return e;
	}
	
	public Customer addCustomer(Customer emp) {
		map.put(emp.getId(), emp);
		return emp;
	}
}
