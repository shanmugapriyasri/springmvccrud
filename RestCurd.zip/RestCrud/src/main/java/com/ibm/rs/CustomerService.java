package com.ibm.rs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/customer")
public class CustomerService {

	private static final CustomerDao dao=new CustomerDao();

	@GET
	@Path("/{id}")
@Produces({MediaType.APPLICATION_JSON})
	public Customer getCustomer(@PathParam("id") Integer id){
		Customer emp=dao.getCustomer(id);
		return emp;
	}
	
	@POST
	@Path("/add")
@Produces({MediaType.APPLICATION_JSON})
	public Customer addCustomer(Customer e){
		Customer emp=dao.addCustomer(e);
		return emp;
	}
	
}
