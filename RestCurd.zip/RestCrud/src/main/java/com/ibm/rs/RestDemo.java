package com.ibm.rs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/hi")
public class RestDemo {

	public RestDemo() {
		System.out.println("Rest Demo cons");
	}
	@GET
	@Path("/say")
	public String sayHi() {
		return "Welcome to JAX_RS ";
	}
	
	@GET
	@Path("/hello/{fname}")
	public String hello(@PathParam("fname")String fname){
		return "Hello "+fname;
	}
}
