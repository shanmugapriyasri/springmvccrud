package com.ibm.rs;

import java.util.List;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
@Path("/emp")
public class EmployeeService  {
	static final EmployeeDao dao=new EmployeeDao();
	@GET
	@Path("/allemp")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Employee> getAllEmp(){
		List<Employee> emplist=dao.getAllemployee();
		return emplist;
	}
	@GET
	@Path("/{eid}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee getById(@PathParam("eid") String eid){
		System.out.println("eid:"+eid);
		Employee emp=dao.getbyid(eid);
		return emp;
	}
	@PUT
	@Path("/update")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
//	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee update(Employee e){
		System.out.println("update"+e);
		Employee emp=dao.updateEmployee(e);
		return emp;
	}
	@DELETE
	@Path("/delete/{eid}")
	public String delete(@PathParam("eid")String eid){
		System.out.println(eid+"del");
		dao.deleteEmployee(eid);
		return eid+" Deleted";
	}
	@POST
	@Path("/add")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
//	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee addemp(@FormParam("eid")String eid,
			@FormParam("name")String name,
			@FormParam("post")String post){
		System.out.println("form"+eid+name+post);
		Employee e=new Employee(eid, name, post);
		Employee emp=dao.addEmployee(e);
		return emp;
	}
	
	//http://localhost:8083/RestCrud/emp/qpara?eid=E01
	@GET
	@Path("/qpara")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee getById1(@QueryParam("eid") String eid){
		System.out.println("eid:"+eid);
		Employee emp=dao.getbyid(eid);
		return emp;
	}
	
	//http://localhost:8083/RestCrud/emp/addm;eid=e55;name=sss;post=ssss
	@POST
	@Path("/addm")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
//	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee addemp1(@MatrixParam("eid")String eid,
			@MatrixParam("name")String name,
			@MatrixParam("post")String post){
		System.out.println("form"+eid+name+post);
		Employee e=new Employee(eid, name, post);
		Employee emp=dao.addEmployee(e);
		return emp;
	}
	
	@GET
	@Path("/details")
	public Response getDetails(@HeaderParam("user-agent")String agent,
			@HeaderParam("content-type")String typedata) {
		String data=agent+" == "+typedata;
		return Response.ok(data).build();
	}
}
	





